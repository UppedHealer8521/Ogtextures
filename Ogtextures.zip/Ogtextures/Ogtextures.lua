--- STEAMODDED HEADER
--- MOD_NAME: Ogtextures
--- MOD_ID: Ogtextures
--- MOD_AUTHOR: [UppedHealer8521]
--- MOD_DESCRIPTION: the original textures from balatro 0.8.8
----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.EnhancedEnhancements()

    local enhancement_mod = SMODS.findModByID("Ogtextures")
    local sprite_enhancer = SMODS.Sprite:new("Joker", enhancement_mod.path, "Jokers.png", 71, 95, "asset_atli")
    sprite_enhancer:register() 
end

----------------------------------------------
------------MOD CODE END----------------------
